from flask import Blueprint, render_template, request, flash, redirect, url_for, abort
from flask_login import login_required, current_user
from sqlalchemy.exc import IntegrityError
from app.models import db, Course, Review
from app.repositories import CourseRepository, UserRepository, CategoryRepository, ImageRepository

user_repository = UserRepository(db)
course_repository = CourseRepository(db)
category_repository = CategoryRepository(db)
image_repository = ImageRepository(db)

bp = Blueprint('courses', __name__, url_prefix='/courses')

COURSE_PARAMS = [
    'author_id', 'name', 'category_id', 'short_desc', 'full_desc'
]

def params():
    return { p: request.form.get(p) or None for p in COURSE_PARAMS }

def search_params():
    return {
        'name': request.args.get('name'),
        'category_ids': [x for x in request.args.getlist('category_ids') if x],
    }

@bp.route('/')
def index():
    pagination = course_repository.get_pagination_info(**search_params())
    courses = course_repository.get_all_courses(pagination=pagination)
    categories = category_repository.get_all_categories()
    return render_template('courses/index.html',
                           courses=courses,
                           categories=categories,
                           pagination=pagination,
                           search_params=search_params())

@bp.route('/new')
@login_required
def new():
    course = course_repository.new_course()
    categories = category_repository.get_all_categories()
    users = user_repository.get_all_users()
    return render_template('courses/new.html',
                           categories=categories,
                           users=users,
                           course=course)

@bp.route('/create', methods=['POST'])
@login_required
def create():
    f = request.files.get('background_img')
    img = None
    course = None 

    try:
        if f and f.filename:
            img = image_repository.add_image(f)

        image_id = img.id if img else None
        course = course_repository.add_course(**params(), background_image_id=image_id)
    except IntegrityError as err:
        flash(f'Возникла ошибка при записи данных в БД. Проверьте корректность введённых данных. ({err})', 'danger')
        categories = category_repository.get_all_categories()
        users = user_repository.get_all_users()
        return render_template('courses/new.html',
                            categories=categories,
                            users=users,
                            course=course)

    flash(f'Курс {course.name} был успешно добавлен!', 'success')

    return redirect(url_for('courses.index'))




@bp.route('/<int:course_id>')
def show(course_id):
    course = db.get_or_404(Course, course_id)
    # 5 последних отзывов курса
    recent_reviews = Review.query.filter_by(course_id=course_id) \
        .order_by(Review.created_at.desc()) \
        .limit(5).all()

    user_review = None
    if current_user.is_authenticated:
        user_review = Review.query.filter_by(course_id=course_id, user_id=current_user.id).first()

    return render_template('courses/show.html', course=course, reviews=recent_reviews, user_review=user_review)


@bp.route('/<int:course_id>/reviews')
def reviews(course_id):
    course = db.get_or_404(Course, course_id)
    sort_order = request.args.get('sort', 'newest')
    page = request.args.get('page', 1, type=int)


    query = Review.query.filter_by(course_id=course_id)
    if sort_order == 'positive':
        query = query.order_by(Review.rating.desc(), Review.created_at.desc())
    elif sort_order == 'negative':
        query = query.order_by(Review.rating.asc(), Review.created_at.desc())
    else:  # newest
        query = query.order_by(Review.created_at.desc())


    pagination = query.paginate(page=page, per_page=5, error_out=False)
    reviews_list = pagination.items


    user_review = None
    if current_user.is_authenticated:
        user_review = Review.query.filter_by(course_id=course_id, user_id=current_user.id).first()

    return render_template(
        'courses/reviews.html',
        course=course,
        reviews=reviews_list,
        pagination=pagination,
        sort_order=sort_order,
        user_review=user_review
    )


@bp.route('/<int:course_id>/reviews/create', methods=['POST'])
@login_required
def create_review(course_id):
    course = Course.query.get_or_404(course_id)

    # Запрет повторного отзыва
    existing_review = Review.query.filter_by(course_id=course_id, user_id=current_user.id).first()
    if existing_review:
        flash('Вы уже оставили отзыв к этому курсу.', 'warning')
        return redirect(url_for('courses.show', course_id=course_id))

    rating = int(request.form.get('rating', 5))
    text = request.form.get('text', '').strip()

    if not text:
        flash('Текст отзыва не может быть пустым.', 'danger')
        return redirect(url_for('courses.show', course_id=course_id))


    review = Review(
        rating=rating,
        text=text,
        course_id=course_id,
        user_id=current_user.id
    )
    db.session.add(review)


    course.rating_sum = (course.rating_sum or 0) + rating
    course.rating_num = (course.rating_num or 0) + 1

    db.session.commit()
    flash('Ваш отзыв успешно добавлен!', 'success')

    return redirect(url_for('courses.show', course_id=course_id))