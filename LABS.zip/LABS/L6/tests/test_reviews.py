import pytest
from app import create_app
from app.models import Review


@pytest.fixture
def client():
    app = create_app()
    app.config['TESTING'] = True
    app.config['WTF_CSRF_ENABLED'] = False

    with app.test_client() as client:
        with app.app_context():
            yield client


def test_review_model():
    review = Review(
        rating=4,
        text="Очень полезный материал, но есть куда расти.",
        course_id=1,
        user_id=2
    )

    assert review.rating == 4
    assert review.text == "Очень полезный материал, но есть куда расти."
    assert review.course_id == 1
    assert review.user_id == 2


def test_reviews_route(client):
    response = client.get('/courses/1/reviews')

    assert response.status_code in [200, 404]


def test_create_review_unauthorized(client):
    response = client.post('/courses/1/reviews/create', data={
        'rating': 5,
        'text': 'Попытка взлома!'
    })

    assert response.status_code == 302
    assert '/auth/login' in response.headers.get('Location', '') or '/login' in response.headers.get('Location', '')