from datetime import datetime
from flask import Flask, render_template, abort, request, redirect, url_for

app = Flask(__name__)

POSTS = {
    1: {
        "id": 1,
        "title": "Первый пост в блоге",
        "author": "Иван Иванов",
        "created_at": datetime(2026, 2, 5, 14, 30),
        "image": "2d2ab7df-cdbc-48a8-a936-35bba702def5.jpg",
        "content": "Это подробное текстовое содержимое первого поста. Описываем основы Flask и Jinja2.",
        "comments": [
            {
                "id": 101,
                "author": "Петр Петров",
                "text": "Отличная статья! Все очень понятно расписано.",
                "created_at": datetime(2026, 2, 5, 15, 0),
                "replies": [
                    {
                        "id": 201,
                        "author": "Иван Иванов",
                        "text": "Спасибо за отзыв!",
                        "created_at": datetime(2026, 2, 5, 15, 10)
                    }
                ]
            },
            {
                "id": 102,
                "author": "Анна Сидорова",
                "text": "Жду продолжения этой серии постов.",
                "created_at": datetime(2026, 2, 5, 16, 20),
                "replies": []
            }
        ]
    },
    2: {
        "id": 2,
        "title": "Второй пост с красивым фото",
        "author": "Мария Смирнова",
        "created_at": datetime(2026, 2, 6, 10, 15),
        "image": "6e12f3de-d5fd-4ebb-855b-8cbc485278b7.jpg",
        "content": "Содержимое второго поста. Здесь мы тестируем загрузку изображений.",
        "comments": []
    }
}


def format_date(dt):
    """Форматирует дату публикации в формат ДД.ММ.ГГГГ ЧЧ:ММ"""
    if isinstance(dt, datetime):
        return dt.strftime("%d.%m.%Y %H:%M")
    return str(dt)


@app.route("/")
def index():
    posts_list = []
    for p in POSTS.values():
        post_copy = p.copy()
        post_copy["formatted_date"] = format_date(post_copy["created_at"])
        posts_list.append(post_copy)
    return render_template("index.html", posts=posts_list)


@app.route("/post/<int:post_id>")
def post_detail(post_id):
    post = POSTS.get(post_id)
    if not post:
        abort(404)

    post_data = post.copy()
    post_data["formatted_date"] = format_date(post_data["created_at"])

    formatted_comments = []
    for c in post_data.get("comments", []):
        c_copy = c.copy()
        c_copy["formatted_date"] = format_date(c_copy["created_at"])

        formatted_replies = []
        for r in c_copy.get("replies", []):
            r_copy = r.copy()
            r_copy["formatted_date"] = format_date(r_copy["created_at"])
            formatted_replies.append(r_copy)

        c_copy["replies"] = formatted_replies
        formatted_comments.append(c_copy)

    post_data["comments"] = formatted_comments
    return render_template("post.html", post=post_data)


@app.route("/post/<int:post_id>/comment", methods=["POST"])
def add_comment(post_id):
    post = POSTS.get(post_id)
    if not post:
        abort(404)

    comment_text = request.form.get("comment_text")
    if comment_text:
        new_comment = {
            "id": len(post["comments"]) + 100,
            "author": "Гость",
            "text": comment_text,
            "created_at": datetime.now(),
            "replies": []
        }
        post["comments"].append(new_comment)

    return redirect(url_for("post_detail", post_id=post_id))


@app.errorhandler(404)
def page_not_found(e):
    return render_template("404.html"), 404


if __name__ == "__main__":
    app.run(debug=True)