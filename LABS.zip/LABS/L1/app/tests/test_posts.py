import pytest
from app.app import app  # Указан точный путь к объекту Flask

@pytest.fixture
def client():
    app.config['TESTING'] = True
    with app.test_client() as client:
        yield client

def test_index_status_code(client):
    response = client.get('/')
    assert response.status_code == 200

def test_index_template_used(client):
    response = client.get('/')
    assert "Мой Блог".encode('utf-8') in response.data

def test_post_detail_status_code_success(client):
    response = client.get('/post/1')
    assert response.status_code == 200

def test_post_detail_status_code_404(client):
    response = client.get('/post/99999')
    assert response.status_code == 404

def test_post_detail_title(client):
    response = client.get('/post/1')
    assert "Первый пост в блоге".encode('utf-8') in response.data

def test_post_detail_author(client):
    response = client.get('/post/1')
    assert "Иван Иванов".encode('utf-8') in response.data

def test_post_detail_content(client):
    response = client.get('/post/1')
    assert "Это подробное текстовое содержимое первого поста".encode('utf-8') in response.data

def test_post_detail_date_format(client):
    response = client.get('/post/1')
    assert "05.02.2026 14:30".encode('utf-8') in response.data

def test_post_detail_image(client):
    response = client.get('/post/1')
    assert "2d2ab7df-cdbc-48a8-a936-35bba702def5.jpg".encode('utf-8') in response.data

def test_comment_form_present(client):
    response = client.get('/post/1')
    assert "comment_text".encode('utf-8') in response.data

def test_comments_rendered(client):
    response = client.get('/post/1')
    assert "Отличная статья! Все очень понятно расписано.".encode('utf-8') in response.data
    assert "Петр Петров".encode('utf-8') in response.data

def test_replies_rendered(client):
    response = client.get('/post/1')
    assert "Спасибо за отзыв!".encode('utf-8') in response.data

def test_post_data_in_context(client):
    response = client.get('/post/2')
    assert response.status_code == 200
    assert "Второй пост с красивым фото".encode('utf-8') in response.data
    assert "Мария Смирнова".encode('utf-8') in response.data

def test_footer_info_present(client):
    response = client.get('/post/1')
    assert "Каримов Андрей Евгеньевич".encode('utf-8') in response.data
    assert "241-371".encode('utf-8') in response.data

def test_add_comment(client):
    response = client.post('/post/1/comment', data={'comment_text': 'Новый тестовый комментарий'}, follow_redirects=True)
    assert response.status_code == 200
    assert "Новый тестовый комментарий".encode('utf-8') in response.data

def test_add_comment_nonexistent_post(client):
    response = client.post('/post/99999/comment', data={'comment_text': 'Тест'})
    assert response.status_code == 404