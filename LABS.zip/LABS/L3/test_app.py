import unittest
from app import app


class FlaskLabTestCase(unittest.TestCase):
    def setUp(self):

        app.config['TESTING'] = True
        app.config['WTF_CSRF_ENABLED'] = False
        self.client = app.test_client()


    def test_01_counter_increments(self):
        resp1 = self.client.get('/counter')
        self.assertIn('<strong>1</strong>', resp1.data.decode('utf-8'))
        resp2 = self.client.get('/counter')
        self.assertIn('<strong>2</strong>', resp2.data.decode('utf-8'))


    def test_02_counter_independence(self):
        # Первый клиент
        self.client.get('/counter')
        self.client.get('/counter')


        client2 = app.test_client()
        resp = client2.get('/counter')
        self.assertIn('<strong>1</strong>', resp.data.decode('utf-8'))


    def test_03_successful_login(self):
        resp = self.client.post('/login', data={'username': 'user', 'password': 'qwerty'}, follow_redirects=True)
        self.assertEqual(resp.request.path, '/')
        self.assertIn('Успешный вход!', resp.data.decode('utf-8'))


    def test_04_failed_login(self):
        resp = self.client.post('/login', data={'username': 'user', 'password': 'wrong_password'},
                                follow_redirects=True)
        self.assertEqual(resp.request.path, '/login')
        self.assertIn('Неверное имя пользователя или пароль.', resp.data.decode('utf-8'))


    def test_05_secret_page_access_authenticated(self):
        self.client.post('/login', data={'username': 'user', 'password': 'qwerty'})
        resp = self.client.get('/secret')
        self.assertEqual(resp.status_code, 200)
        self.assertIn('Секретная страница', resp.data.decode('utf-8'))


    def test_06_secret_page_redirects_unauthenticated(self):
        resp = self.client.get('/secret', follow_redirects=True)
        self.assertEqual(resp.request.path, '/login')
        self.assertIn('Пожалуйста, авторизуйтесь', resp.data.decode('utf-8'))


    def test_07_login_redirects_to_next(self):
        resp = self.client.post('/login?next=/secret', data={'username': 'user', 'password': 'qwerty'},
                                follow_redirects=True)
        self.assertEqual(resp.request.path, '/secret')


    def test_08_remember_me_sets_cookie(self):
        resp = self.client.post('/login', data={'username': 'user', 'password': 'qwerty', 'remember': 'on'})
        cookies = resp.headers.getlist('Set-Cookie')
        remember_cookie_found = any('remember_token' in cookie for cookie in cookies)
        self.assertTrue(remember_cookie_found)


    def test_09_navbar_hides_links_for_guest(self):
        resp = self.client.get('/')
        html = resp.data.decode('utf-8')
        self.assertIn('Войти', html)
        self.assertNotIn('Секретная страница', html)
        self.assertNotIn('Выйти', html)


    def test_10_navbar_shows_links_for_user(self):
        self.client.post('/login', data={'username': 'user', 'password': 'qwerty'})
        resp = self.client.get('/')
        html = resp.data.decode('utf-8')
        self.assertNotIn('Войти', html)
        self.assertIn('Секретная страница', html)
        self.assertIn('Выйти', html)


if __name__ == '__main__':
    unittest.main()