import re
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, flash
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from models import db, User, Role, VisitLog
from reports import reports_bp

app = Flask(__name__)
app.config['SECRET_KEY'] = 'super-secret-key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///app.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
login_manager.login_message = "У вас недостаточно прав"
app.register_blueprint(reports_bp)


@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))



def check_rights(action):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.is_authenticated:
                flash("У вас недостаточно прав для доступа к данной странице.", "danger")
                return redirect(url_for('index'))

            role_name = current_user.role.name if current_user.role else None
            is_admin = role_name == 'Администратор'

            has_access = False
            if is_admin:
                has_access = True
            elif role_name == 'Пользователь':
                if action in ['edit', 'view'] and kwargs.get('user_id') == current_user.id:
                    has_access = True
                elif action == 'view_logs':
                    has_access = True

            if not has_access:
                flash("У вас недостаточно прав для доступа к данной странице.", "danger")
                return redirect(url_for('index'))

            return f(*args, **kwargs)

        return decorated_function

    return decorator


@app.before_request
def log_visit():
    if request.endpoint and 'static' not in request.endpoint:
        log = VisitLog(
            path=request.path,
            user_id=current_user.id if current_user.is_authenticated else None
        )
        db.session.add(log)
        db.session.commit()


def validate_password(pwd):
    if len(pwd) < 8 or len(pwd) > 128: return False, "Длина пароля должна быть от 8 до 128 символов"
    if ' ' in pwd: return False, "Пароль не должен содержать пробелов"
    if not re.search(r'[a-zа-яё]', pwd): return False, "Минимум одна строчная буква"
    if not re.search(r'[A-ZА-ЯЁ]', pwd): return False, "Минимум одна заглавная буква"
    if not re.search(r'\d', pwd): return False, "Минимум одна цифра"
    allowed = set(
        "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZа-яА-ЯёЁ0123456789~!?@#$%^&*_-+()[]{}></\\|\"',.:;")
    if not all(c in allowed for c in pwd): return False, "Содержит недопустимые символы"
    return True, ""


def validate_user_data(data, is_edit=False):
    errors = {}
    if not is_edit:
        login = data.get('login', '')
        if not login:
            errors['login'] = "Поле логин не может быть пустым"
        elif len(login) < 5 or not re.match(r'^[a-zA-Z0-9]+$', login):
            errors['login'] = "Логин: только латинские буквы/цифры, длина от 5"
        elif User.query.filter_by(login=login).first():
            errors['login'] = "Пользователь с таким логином уже существует"
        pwd = data.get('password', '')
        if not pwd:
            errors['password'] = "Поле пароль не может быть пустым"
        else:
            valid, msg = validate_password(pwd)
            if not valid: errors['password'] = msg
    if not data.get('last_name'): errors['last_name'] = "Фамилия не может быть пустой"
    if not data.get('first_name'): errors['first_name'] = "Имя не может быть пустым"
    return errors


@app.route('/')
def index():
    users = User.query.all()
    return render_template('index.html', users=users)


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        login = request.form.get('login')
        password = request.form.get('password')
        user = User.query.filter_by(login=login).first()
        if user and check_password_hash(user.password_hash, password):
            login_user(user)
            return redirect(url_for('index'))
        flash('Неверный логин или пароль', 'danger')
    return render_template('login.html')


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))


@app.route('/view/<int:user_id>')
@login_required
@check_rights('view')
def view_user(user_id):
    user = db.session.get(User, user_id)
    if not user: return "Not found", 404
    return render_template('view.html', user=user)


@app.route('/create', methods=['GET', 'POST'])
@login_required
@check_rights('create')
def create_user():
    roles = Role.query.all()
    errors = {}
    if request.method == 'POST':
        errors = validate_user_data(request.form, is_edit=False)
        if not errors:
            try:
                new_user = User(
                    login=request.form['login'],
                    password_hash=generate_password_hash(request.form['password']),
                    last_name=request.form['last_name'],
                    first_name=request.form['first_name'],
                    middle_name=request.form.get('middle_name', ''),
                    role_id=request.form.get('role_id') or None
                )
                db.session.add(new_user)
                db.session.commit()
                flash('Пользователь успешно создан!', 'success')
                return redirect(url_for('index'))
            except Exception:
                db.session.rollback()
                flash('Ошибка при сохранении в БД.', 'danger')
        else:
            flash('Пожалуйста, исправьте ошибки в форме.', 'danger')
    return render_template('create.html', roles=roles, errors=errors, data=request.form)


@app.route('/edit/<int:user_id>', methods=['GET', 'POST'])
@login_required
@check_rights('edit')
def edit_user(user_id):
    user = db.session.get(User, user_id)
    if not user: return "Not found", 404
    roles = Role.query.all()
    errors = {}
    is_admin = current_user.role.name == 'Администратор'

    if request.method == 'POST':
        errors = validate_user_data(request.form, is_edit=True)
        if not errors:
            try:
                user.last_name = request.form['last_name']
                user.first_name = request.form['first_name']
                user.middle_name = request.form.get('middle_name', '')
                if is_admin:
                    user.role_id = request.form.get('role_id') or None
                db.session.commit()
                flash('Данные успешно обновлены!', 'success')
                return redirect(url_for('index'))
            except:
                db.session.rollback()
                flash('Ошибка при сохранении в БД.', 'danger')
        else:
            flash('Пожалуйста, исправьте ошибки в форме.', 'danger')

    data = request.form if request.method == 'POST' else {
        'last_name': user.last_name, 'first_name': user.first_name,
        'middle_name': user.middle_name, 'role_id': user.role_id
    }
    return render_template('edit.html', user=user, roles=roles, errors=errors, data=data, is_admin=is_admin)


@app.route('/delete/<int:user_id>', methods=['POST'])
@login_required
@check_rights('delete')
def delete_user(user_id):
    user = db.session.get(User, user_id)
    if user:
        try:
            db.session.delete(user)
            db.session.commit()
            flash('Пользователь удален.', 'success')
        except:
            db.session.rollback()
            flash('Ошибка при удалении.', 'danger')
    return redirect(url_for('index'))


@app.route('/change_password', methods=['GET', 'POST'])
@login_required
def change_password():
    return render_template('change_password.html', errors={})


if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        if not Role.query.first():
            db.session.add(Role(name='Администратор', description='Администратор системы'))
            db.session.add(Role(name='Пользователь', description='Обычный пользователь'))
            db.session.commit()

        if not User.query.first():
            admin_role = Role.query.filter_by(name='Администратор').first()
            default_admin = User(
                login='admin',
                password_hash=generate_password_hash('Password123!'),
                last_name='Администраторов',
                first_name='Админ',
                role_id=admin_role.id if admin_role else None
            )
            db.session.add(default_admin)
            db.session.commit()
    app.run(debug=True)