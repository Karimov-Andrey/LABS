import io
import csv
from flask import Blueprint, render_template, request, Response, flash, redirect, url_for
from flask_login import current_user, login_required
from sqlalchemy import func
from models import db, VisitLog, User

reports_bp = Blueprint('reports', __name__, url_prefix='/reports')


@reports_bp.route('/logs')
@login_required
def logs():

    page = request.args.get('page', 1, type=int)
    query = VisitLog.query.order_by(VisitLog.created_at.desc())

    if current_user.role.name == 'Пользователь':
        query = query.filter_by(user_id=current_user.id)

    pagination = query.paginate(page=page, per_page=10, error_out=False)
    return render_template('reports/logs.html', pagination=pagination)


@reports_bp.route('/pages')
@login_required
def stat_pages():
    if current_user.role.name != 'Администратор':
        flash("У вас недостаточно прав для доступа к данной странице.", "danger")
        return redirect(url_for('index'))

    stats = db.session.query(VisitLog.path, func.count(VisitLog.id).label('count')) \
        .group_by(VisitLog.path).order_by(func.count(VisitLog.id).desc()).all()
    return render_template('reports/stat_pages.html', stats=stats)


@reports_bp.route('/pages/export')
@login_required
def export_pages():
    if current_user.role.name != 'Администратор':
        return redirect(url_for('index'))

    stats = db.session.query(VisitLog.path, func.count(VisitLog.id).label('count')) \
        .group_by(VisitLog.path).order_by(func.count(VisitLog.id).desc()).all()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['№', 'Страница', 'Количество посещений'])
    for idx, stat in enumerate(stats, 1):
        writer.writerow([idx, stat.path, stat.count])

    return Response(output.getvalue().encode('utf-8-sig'), mimetype='text/csv',
                    headers={"Content-Disposition": "attachment;filename=pages_stat.csv"})


@reports_bp.route('/users')
@login_required
def stat_users():
    if current_user.role.name != 'Администратор':
        flash("У вас недостаточно прав для доступа к данной странице.", "danger")
        return redirect(url_for('index'))

    stats = db.session.query(VisitLog.user_id, func.count(VisitLog.id).label('count')) \
        .group_by(VisitLog.user_id).order_by(func.count(VisitLog.id).desc()).all()

    users_data = []
    for stat in stats:
        name = "Неаутентифицированный пользователь"
        if stat.user_id:
            user = db.session.get(User, stat.user_id)
            name = user.full_name if user else "Неизвестный"
        users_data.append({'name': name, 'count': stat.count})

    return render_template('reports/stat_users.html', stats=users_data)


@reports_bp.route('/users/export')
@login_required
def export_users():
    if current_user.role.name != 'Администратор':
        return redirect(url_for('index'))

    stats = db.session.query(VisitLog.user_id, func.count(VisitLog.id).label('count')) \
        .group_by(VisitLog.user_id).order_by(func.count(VisitLog.id).desc()).all()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['№', 'Пользователь', 'Количество посещений'])
    for idx, stat in enumerate(stats, 1):
        name = "Неаутентифицированный пользователь"
        if stat.user_id:
            user = db.session.get(User, stat.user_id)
            name = user.full_name if user else "Неизвестный"
        writer.writerow([idx, name, stat.count])

    return Response(output.getvalue().encode('utf-8-sig'), mimetype='text/csv',
                    headers={"Content-Disposition": "attachment;filename=users_stat.csv"})