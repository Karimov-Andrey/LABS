import pytest
from app import app, db
from models import User, Role, VisitLog
from werkzeug.security import generate_password_hash


@pytest.fixture
def client():
    app.config['TESTING'] = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
    app.config['WTF_CSRF_ENABLED'] = False

    with app.test_client() as client:
        with app.app_context():
            db.drop_all()
            db.create_all()

            admin_role = Role(name='Администратор')
            user_role = Role(name='Пользователь')
            db.session.add_all([admin_role, user_role])
            db.session.commit()

            admin_user = User(
                login='admin',
                password_hash=generate_password_hash('Password123!'),
                last_name='Иванов',
                first_name='Иван',
                role_id=admin_role.id
            )
            normal_user = User(
                login='user',
                password_hash=generate_password_hash('Password123!'),
                last_name='Петров',
                first_name='Петр',
                role_id=user_role.id
            )
            db.session.add_all([admin_user, normal_user])
            db.session.commit()

        yield client


        with app.app_context():
            db.session.remove()
            db.drop_all()


def test_index_unauth(client):
    response = client.get('/')
    assert b'\xd0\x92\xd1\x85\xd0\xbe\xd0\xb4' in response.data


def test_login(client):
    response = client.post('/login', data={'login': 'admin', 'password': 'Password123!'}, follow_redirects=True)
    assert b'\xd0\x92\xd1\x8b\xd1\x85\xd0\xbe\xd0\xb4' in response.data


def test_create_user_unauth(client):
    response = client.get('/create', follow_redirects=True)
    assert b'\xd0\xa3 \xd0\xb2\xd0\xb0\xd1\x81 \xd0\xbd\xd0\xb5\xd0\xb4\xd0\xbe\xd1\x81\xd1\x82\xd0\xb0\xd1\x82\xd0\xbe\xd1\x87\xd0\xbd\xd0\xbe \xd0\xbf\xd1\x80\xd0\xb0\xd0\xb2' in response.data


def test_password_validation():
    from app import validate_password
    assert validate_password('short')[0] == False
    assert validate_password('NoDigitsHere!')[0] == False
    assert validate_password('ValidPass123!')[0] == True


def test_access_denied_for_guest(client):
    response = client.get('/create', follow_redirects=True)
    assert b'\xd0\xa3 \xd0\xb2\xd0\xb0\xd1\x81 \xd0\xbd\xd0\xb5\xd0\xb4\xd0\xbe\xd1\x81\xd1\x82\xd0\xb0\xd1\x82\xd0\xbe\xd1\x87\xd0\xbd\xd0\xbe \xd0\xbf\xd1\x80\xd0\xb0\xd0\xb2' in response.data  # "У вас недостаточно прав"


def test_visit_logging(client):
    client.get('/')
    with app.app_context():
        logs = VisitLog.query.all()
        assert len(logs) > 0
        assert logs[-1].path == '/'