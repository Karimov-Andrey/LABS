import re
from flask import Flask, make_response, redirect, render_template, request, url_for

app = Flask(__name__)
app.config["SECRET_KEY"] = "your-secret-key-for-testing"


@app.route("/")
def index():
  return render_template("index.html")


@app.route("/url-params")
def url_params():
  return render_template("url_params.html", params=request.args.items())


@app.route("/headers")
def headers():
  return render_template("headers.html", headers=request.headers.items())


@app.route("/cookies", methods=["GET", "POST"])
def cookies_view():
  cookie_name = "test_task_cookie"

  if request.method == "POST":
    # Кнопка переключения состояния куки
    resp = redirect(url_for("cookies_view"))
    if request.cookies.get(cookie_name):
      resp.set_cookie(cookie_name, "", expires=0)
    else:
      resp.set_cookie(cookie_name, "active_value")
    return resp

  cookie_value = request.cookies.get(cookie_name)
  return render_template(
      "cookies.html", cookie_name=cookie_name, cookie_value=cookie_value
  )


@app.route("/form-params", methods=["GET", "POST"])
def form_params():
  return render_template(
      "form_params.html", form_data=request.form if request.method == "POST" else None
  )


def format_phone_number(digits):
  if len(digits) == 11:
    d = digits[1:]
    return f"8-{d[0:3]}-{d[3:6]}-{d[6:8]}-{d[8:10]}"
  elif len(digits) == 10:
    return f"8-{digits[0:3]}-{digits[3:6]}-{digits[6:8]}-{digits[8:10]}"
  return digits


@app.route("/phone-validation", methods=["GET", "POST"])
def phone_validation():
  error_message = None
  formatted_phone = None
  raw_input = ""

  if request.method == "POST":
    raw_input = request.form.get("phone", "").strip()


    if re.search(r"[^\d\s\(\)\-\.\+]", raw_input):
      error_message = "Недопустимый ввод. В номере телефона встречаются недопустимые символы."
    else:

      digits = re.findall(r"\d", raw_input)
      total_digits = len(digits)
      digits_str = "".join(digits)

      is_valid_count = False
      if total_digits == 11:
        if digits_str.startswith("7") or digits_str.startswith("8"):
          is_valid_count = True
      elif total_digits == 10:

        if not (digits_str.startswith("7") or digits_str.startswith("8")):
          is_valid_count = True

      if not is_valid_count:
        error_message = "Недопустимый ввод. Неверное количество цифр."
      else:
        formatted_phone = format_phone_number(digits_str)

  return render_template(
      "phone_form.html",
      error_message=error_message,
      formatted_phone=formatted_phone,
      raw_input=raw_input,
  )


if __name__ == "__main__":
  app.run(debug=True)