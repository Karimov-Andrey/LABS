import unittest
import os
import sys
import unittest
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from app import app, format_phone_number


class FlaskAppTestCase(unittest.TestCase):

  def setUp(self):
    self.app = app
    self.app.config['TESTING'] = True
    self.client = self.app.test_client()

  # 1. Тест отображения параметров URL
  def test_url_params_displayed(self):
    response = self.client.get('/url-params?param1=test_val&foo=bar')
    self.assertEqual(response.status_code, 200)
    self.assertIn(b'param1', response.data)
    self.assertIn(b'test_val', response.data)
    self.assertIn(b'foo', response.data)
    self.assertIn(b'bar', response.data)

  def test_url_params_empty(self):
    response = self.client.get('/url-params')
    self.assertEqual(response.status_code, 200)
    self.assertIn('Параметры отсутствуют'.encode('utf-8'), response.data)

  # 2. Тест отображения заголовков запроса
  def test_headers_displayed(self):
    response = self.client.get(
        '/headers', headers={'X-Custom-Header': 'TestValue123'}
    )
    self.assertEqual(response.status_code, 200)
    self.assertIn(b'X-Custom-Header', response.data)
    self.assertIn(b'TestValue123', response.data)
    self.assertIn(b'User-Agent', response.data)

  # 3. Тесты работы с Cookie (установка и удаление)
  def test_cookie_lifecycle(self):
    cookie_name = "test_task_cookie"

    # Шаг А: Изначально куки нет
    response = self.client.get("/cookies")
    self.assertEqual(response.status_code, 200)
    self.assertIsNone(self.client.get_cookie(cookie_name))

    # Шаг Б: Отправляем POST для установки куки
    response = self.client.post("/cookies", follow_redirects=True)
    self.assertEqual(response.status_code, 200)
    self.assertIn("Установлено".encode("utf-8"), response.data)
    self.assertIsNotNone(self.client.get_cookie(cookie_name))

    # Шаг В: Отправляем POST для удаления куки
    response = self.client.post("/cookies", follow_redirects=True)
    self.assertEqual(response.status_code, 200)
    self.assertIn("Не установлено".encode("utf-8"), response.data)
    # После удаления значение куки становится пустым
    cookie = self.client.get_cookie(cookie_name)
    self.assertTrue(cookie is None or cookie.value == "")

  # 4. Тесты параметров формы
  def test_form_params_submission(self):
    response = self.client.post(
        '/form-params', data={'sample_input': 'HelloFlask'}
    )
    self.assertEqual(response.status_code, 200)
    self.assertIn(b'HelloFlask', response.data)
    self.assertIn(b'sample_input', response.data)

  def test_form_params_empty_post(self):
    response = self.client.post('/form-params', data={})
    self.assertEqual(response.status_code, 200)
    self.assertIn('Полученные данные'.encode('utf-8'), response.data)

  # 5. Валидация и форматирование телефона
  def test_phone_valid_format_1_plus7(self):
    # +7 (123) 456-75-90 -> 11 цифр, начинается с 7
    response = self.client.post(
        '/phone-validation', data={'phone': '+7 (123) 456-75-90'}
    )
    self.assertEqual(response.status_code, 200)
    self.assertIn(b'8-123-456-75-90', response.data)
    self.assertNotIn(b'is-invalid', response.data)

  def test_phone_valid_format_2_eight(self):
    # 8(123)4567590 -> 11 цифр, начинается с 8
    response = self.client.post(
        '/phone-validation', data={'phone': '8(123)4567590'}
    )
    self.assertEqual(response.status_code, 200)
    self.assertIn(b'8-123-456-75-90', response.data)

  def test_phone_valid_format_3_dots(self):
    # 123.456.75.90 -> 10 цифр (без префикса 7/8)
    response = self.client.post(
        '/phone-validation', data={'phone': '123.456.75.90'}
    )
    self.assertEqual(response.status_code, 200)
    self.assertIn(b'8-123-456-75-90', response.data)

  def test_phone_invalid_length_short(self):
    # Неверное количество цифр (слишком короткий)
    response = self.client.post('/phone-validation', data={'phone': '123-45'})
    self.assertEqual(response.status_code, 200)
    self.assertIn(
        'Недопустимый ввод. Неверное количество цифр.'.encode('utf-8'),
        response.data,
    )
    self.assertIn(b'is-invalid', response.data)
    self.assertIn(b'invalid-feedback', response.data)

  def test_phone_invalid_length_long(self):
    # Неверное количество цифр (слишком длинный)
    response = self.client.post(
        '/phone-validation', data={'phone': '812345675901'}
    )
    self.assertEqual(response.status_code, 200)
    self.assertIn(
        'Недопустимый ввод. Неверное количество цифр.'.encode('utf-8'),
        response.data,
    )
    self.assertIn(b'is-invalid', response.data)

  def test_phone_invalid_prefix_mismatch(self):
    # 11 цифр, но начинается с другой цифры (например, 9)
    response = self.client.post(
        '/phone-validation', data={'phone': '91234567590'}
    )
    self.assertEqual(response.status_code, 200)
    self.assertIn(
        'Недопустимый ввод. Неверное количество цифр.'.encode('utf-8'),
        response.data,
    )

  def test_phone_invalid_symbols_letters(self):
    # Наличие недопустимых символов (буквы)
    response = self.client.post(
        '/phone-validation', data={'phone': '+7(123)abc-7590'}
    )
    self.assertEqual(response.status_code, 200)
    self.assertIn(
        'Недопустимый ввод. В номере телефона встречаются недопустимые'
        ' символы.'.encode('utf-8'),
        response.data,
    )
    self.assertIn(b'is-invalid', response.data)
    self.assertIn(b'invalid-feedback', response.data)

  def test_phone_invalid_symbols_special(self):
    # Наличие недопустимых спецсимволов
    response = self.client.post(
        '/phone-validation', data={'phone': '123-456-$75-90'}
    )
    self.assertEqual(response.status_code, 200)
    self.assertIn(
        'Недопустимый ввод. В номере телефона встречаются недопустимые'
        ' символы.'.encode('utf-8'),
        response.data,
    )

  def test_phone_empty_input(self):
    # Тест пустой отправки формы
    response = self.client.post('/phone-validation', data={'phone': ''})
    self.assertEqual(response.status_code, 200)
    self.assertIn(
        'Недопустимый ввод. Неверное количество цифр.'.encode('utf-8'),
        response.data,
    )

  def test_helper_formatting_function(self):
    # Юнит-тест функции форматирования
    self.assertEqual(format_phone_number('71234567590'), '8-123-456-75-90')
    self.assertEqual(format_phone_number('1234567590'), '8-123-456-75-90')


if __name__ == '__main__':
  unittest.main()