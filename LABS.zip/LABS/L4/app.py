import re
from flask import Flask, render_template, request, redirect, url_for, flash
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from models import db, User, Role

app = Flask(__name__)
app.config['SECRET_KEY'] = 'super-secret-key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///app.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'


@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))


def validate_password(pwd):
    if len(pwd) < 8 or len(pwd) > 128: return False, "Длина пароля должна быть от 8 до 128 символов"
    if ' ' in pwd: return False, "Пароль не должен содержать пробелов"
    if not re.search(r'[a-zа-яё]', pwd): return False, "Минимум одна строчная буква"
    if not re.search(r'[A-ZА-ЯЁ]', pwd): return False, "Минимум одна заглавная буква"
    if not re.search(r'\d', pwd): return False, "Минимум одна цифра"

    allowed = set(
        "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZа-яА-ЯёЁ0123456789~!?@#$%^&*_-+()[]{}></\\|\"',.:;")
    if not all(c in allowed for c in pwd): return False, "Содержит недопустимые символы"
    return True, ""


def validate_user_data(data, is_edit=False):
    errors = {}
    if not is_edit:
        login = data.get('login', '')
        if not login:
            errors['login'] = "Поле логин не может быть пустым"
        elif len(login) < 5 or not re.match(r'^[a-zA-Z0-9]+$', login):
            errors['login'] = "Логин: только латинские буквы/цифры, длина от 5"
        elif User.query.filter_by(login=login).first():
            errors['login'] = "Пользователь с таким логином уже существует"

        pwd = data.get('password', '')
        if not pwd:
            errors['password'] = "Поле пароль не может быть пустым"
        else:
            valid, msg = validate_password(pwd)
            if not valid: errors['password'] = msg

    if not data.get('last_name'): errors['last_name'] = "Фамилия не может быть пустой"
    if not data.get('first_name'): errors['first_name'] = "Имя не может быть пустым"
    return errors


@app.route('/')
def index():
    users = User.query.all()
    return render_template('index.html', users=users)


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        login = request.form.get('login')
        password = request.form.get('password')
        user = User.query.filter_by(login=login).first()
        if user and check_password_hash(user.password_hash, password):
            login_user(user)
            return redirect(url_for('index'))
        flash('Неверный логин или пароль', 'danger')
    return render_template('login.html')


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))


@app.route('/view/<int:user_id>')
def view_user(user_id):
    user = db.session.get(User, user_id)
    if not user: return "Not found", 404
    return render_template('view.html', user=user)


@app.route('/create', methods=['GET', 'POST'])
@login_required
def create_user():
    roles = Role.query.all()
    errors = {}
    if request.method == 'POST':
        errors = validate_user_data(request.form, is_edit=False)
        if not errors:
            try:
                new_user = User(
                    login=request.form['login'],
                    password_hash=generate_password_hash(request.form['password']),
                    last_name=request.form['last_name'],
                    first_name=request.form['first_name'],
                    middle_name=request.form.get('middle_name', ''),
                    role_id=request.form.get('role_id') or None
                )
                db.session.add(new_user)
                db.session.commit()
                flash('Пользователь успешно создан!', 'success')
                return redirect(url_for('index'))
            except Exception as e:
                db.session.rollback()
                flash('Ошибка при сохранении в БД.', 'danger')
        else:
            flash('Пожалуйста, исправьте ошибки в форме.', 'danger')
    return render_template('create.html', roles=roles, errors=errors, data=request.form)


@app.route('/edit/<int:user_id>', methods=['GET', 'POST'])
@login_required
def edit_user(user_id):
    user = db.session.get(User, user_id)
    if not user: return "Not found", 404
    roles = Role.query.all()
    errors = {}

    if request.method == 'POST':
        errors = validate_user_data(request.form, is_edit=True)
        if not errors:
            try:
                user.last_name = request.form['last_name']
                user.first_name = request.form['first_name']
                user.middle_name = request.form.get('middle_name', '')
                user.role_id = request.form.get('role_id') or None
                db.session.commit()
                flash('Данные успешно обновлены!', 'success')
                return redirect(url_for('index'))
            except:
                db.session.rollback()
                flash('Ошибка при сохранении в БД.', 'danger')
        else:
            flash('Пожалуйста, исправьте ошибки в форме.', 'danger')

    data = request.form if request.method == 'POST' else {
        'last_name': user.last_name, 'first_name': user.first_name,
        'middle_name': user.middle_name, 'role_id': user.role_id
    }
    return render_template('edit.html', user=user, roles=roles, errors=errors, data=data)


@app.route('/delete/<int:user_id>', methods=['POST'])
@login_required
def delete_user(user_id):
    user = db.session.get(User, user_id)
    if user:
        try:
            db.session.delete(user)
            db.session.commit()
            flash('Пользователь удален.', 'success')
        except:
            db.session.rollback()
            flash('Ошибка при удалении.', 'danger')
    return redirect(url_for('index'))


@app.route('/change_password', methods=['GET', 'POST'])
@login_required
def change_password():
    errors = {}
    if request.method == 'POST':
        old_pwd = request.form.get('old_password', '')
        new_pwd = request.form.get('new_password', '')
        new_pwd2 = request.form.get('new_password_2', '')

        if not check_password_hash(current_user.password_hash, old_pwd):
            errors['old_password'] = "Неверный старый пароль"
        if new_pwd != new_pwd2:
            errors['new_password_2'] = "Пароли не совпадают"

        valid, msg = validate_password(new_pwd)
        if not valid: errors['new_password'] = msg

        if not errors:
            current_user.password_hash = generate_password_hash(new_pwd)
            db.session.commit()
            flash('Пароль успешно изменен', 'success')
            return redirect(url_for('index'))

    return render_template('change_password.html', errors=errors)


if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        if not Role.query.first():
            db.session.add(Role(name='Admin', description='Администратор системы'))
            db.session.add(Role(name='User', description='Обычный пользователь'))
            db.session.commit()

        if not User.query.first():
            admin_role = Role.query.filter_by(name='Admin').first()
            default_admin = User(
                login='admin',
                password_hash=generate_password_hash('Password123!'),
                last_name='Администраторов',
                first_name='Админ',
                role_id=admin_role.id if admin_role else None
            )
            db.session.add(default_admin)
            db.session.commit()
            print(">>> Успешно создан тестовый администратор: логин 'admin', пароль 'Password123!'")
    app.run(debug=True)