import pytest
from app import app, db, User, Role
from werkzeug.security import generate_password_hash


@pytest.fixture
def client():
    app.config['TESTING'] = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
    app.config['WTF_CSRF_ENABLED'] = False

    with app.test_client() as client:
        with app.app_context():
            db.create_all()
            db.session.add(Role(name='User'))
            test_user = User.query.filter_by(login='admin').first()
            if not test_user:
                test_user = User(login='admin', password_hash=..., last_name='Иванов', first_name='Иван')
                db.session.add(test_user)
                db.session.commit()
        yield client


def test_index_unauth(client):
    response = client.get('/')
    assert b'\xd0\x92\xd1\x85\xd0\xbe\xd0\xb4' in response.data


def test_login(client):
    response = client.post('/login', data={'login': 'admin', 'password': 'Password123!'}, follow_redirects=True)
    assert b'\xd0\x92\xd1\x8b\xd1\x85\xd0\xbe\xd0\xb4' in response.data  # "Выход"


def test_create_user_unauth(client):
    response = client.get('/create', follow_redirects=True)

    assert b'<form' in response.data


def test_password_validation():
    from app import validate_password
    assert validate_password('short')[0] == False
    assert validate_password('NoDigitsHere!')[0] == False
    assert validate_password('ValidPass123!')[0] == True